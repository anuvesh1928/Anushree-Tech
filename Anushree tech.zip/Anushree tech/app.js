const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const port = 80;

// EXPRESS SPECIFIC STUFF
app.use('/statics', express.static('statics')) // For serving static files
app.use(express.urlencoded())

app.get("/about",(req,res)=>{
    res.sendFile('index.html')
})



// START THE SERVER
app.listen(port, ()=>{
    console.log(`The application started successfully on port ${port}`);
});